﻿namespace Proj2
{
    public interface iRobot
    {
        void Run();
    }
}
